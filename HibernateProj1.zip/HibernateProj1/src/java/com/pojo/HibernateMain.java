/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pojo;

import com.java.util.HibernateUtil;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;



public class HibernateMain {
    

       
    public static void main(String[] args) {

                Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction t=session.beginTransaction();
       
         Scanner sc=new Scanner(System.in);
        int choice;
        System.out.println("1.insert");
        System.out.println("2.update");
        System.out.println("3.delete");
        System.out.println("4.select");
        System.out.println("5.deleteAll");
        System.out.println("Enter choice:");
        choice=sc.nextInt();
        
        switch(choice)
        {
            case 1:
                insertData(session,t);
                break;
            case 2:
                updateData(session,t);
                break;
            case 3:
                delete(session,t);
                break;
            case 4:
                list(session, t);
                break;
            case 5:
                deleteAll(session, t);
                break;
            default:
                System.out.println("Please enter valid number");
                break;
                
        }     
        
        
        
    }
    
    
    public static void insertData(Session session,Transaction t)
    {
        Student student=new Student();
        student.setName("prakash");
        student.setCourse_name("mca02");
        
        session.save(student);
        t.commit();
        System.out.println("successfully inserted");
    }
    
    public static void updateData(Session session,Transaction t)
    {
        int uid=2;
        
       /* Criteria criteria=session.createCriteria(Student.class);
        Projection projection=Projections.property("id");
        criteria.setProjection(projection);
        List list=criteria.list();
        */
       
       Student student=(Student)session.get(Student.class,uid);
       student.setName("ruchika");
       student.setCourse_name("mca05");
       session.save(student);
       t.commit();
        System.out.println("updated successfully");
    }
    
    public static void list(Session session,Transaction t)
    {
       
        Criteria criteria=session.createCriteria(Student.class);
        List<Student> students=criteria.list();
        
        for(Student student:students)
        {
            System.out.println(student.toString());
        }
        
    }
    
    
    
    public static void delete(Session session,Transaction t)
    {
        Criteria criteria=session.createCriteria(Student.class);
        int did=4;
       Student student=(Student)session.get(Student.class,did);
       session.delete(student);
       t.commit();
    }
    
    
    
    
    public static void deleteAll(Session session,Transaction t)
    {
        Criteria criteria=session.createCriteria(Student.class);
        List<Student> students=criteria.list();
        
        for(Student s:students)
        {
            session.delete(s);
        }
        t.commit();
        System.out.println("all data deleted");
        
        
    }
}
